import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { VisDemoModule } from './demo.module';
platformBrowserDynamic().bootstrapModule(VisDemoModule);
